# Examples demonstate how to use deepGLM function to fit data with binary dependent variable
#
# Copyright 2018
#                Nghia Nguyen (nghia.nguyen@sydney.edu.au)
#                Minh-Ngoc Tran (minh-ngoc.tran@sydney.edu.au)
#
# https://github.com/VBayesLab/deepGLM
#
# Version: 1.0
# LAST UPDATE: May, 2018

# Clear all variables
rm(list=ls())

library(mvtnorm)

# Create a simulation dataset
n <- 10000                                      # Total number of observations
n_test <- 1000                                  # Number of observations in test data
n_train <- n-n_test                             # Number of observations for training
d <- 10                                         # Number of covariates
X <- matrix(runif(n*d,min=0,max=2),n,d)         # Geneate design matrix X
muy <- 2 + X[,1]^2 + 3*X[,2] - 5*X[,3]*X[,4] - 2*X[,5]  # Use only 5 covariates to generate data
p <- exp(muy)/(1+exp(muy))                      # Probabilities to be "1" of each observation
y <- as.numeric(p>0.5)                          # Convert probabilities to binary responses
cat("Percentage of 1 responses: ",sum(y)/length(y)*100,"%","/n")
XTest <- X[1:n_test,]                           # Extract 1000 observations for testing
yTest <- y[1:n_test]
XTrain <- X[(n_test+1):n,]                      # Use the rest for training
yTrain <- y[(n_test+1):n]

# Start to train a deepGLM model
deepGLMout <- deepGLMfit(XTrain,yTrain,Network=c(5,5,5),Seed=100,Patience=150,
                         Verbose=1,MaxEpoch=2000,Distribution="binomial")

# Make prediction on test data
Pred <- deepGLMpredict(deepGLMout,XTest,y = yTest)
cat('Classfication rate: ',Pred$accuracy*100,'%','\n')


